<?php
    $passwords = array("juicebox", "juicebox2");

    $passwordRecoveryEmail = "hello@example.com";

    $formText = array(
        "Please enter your password",
        "To request a new password, please email:"
    );
?>
